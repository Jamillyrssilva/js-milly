function setup() { 
  createCanvas(600, 600);
  background("rgb(121,32,32)")
}
function draw() {
  stroke("rgb(248,248,155)");
  fill("rgb(255,201,102)");
  
  if(mouseIsPressed){
    rect(mouseX, mouseY, 20, 35);
  }
  
}